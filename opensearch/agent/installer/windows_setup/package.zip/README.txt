﻿VANT OpenSearch Agent Installer

1) Open PowerShell as Administrator.
2) Choose and copy one config:
   - config.windows-server-ad.yaml
   - config.windows11-ids.yaml
   to config.yaml, then edit endpoint/auth/TLS.
3) Run:
   .\Install-OpenSearchAgent.ps1 -RunNow

Verify:
  Get-ScheduledTask -TaskName VANT-OpenSearch-Agent

Uninstall:
  .\Uninstall-OpenSearchAgent.ps1
